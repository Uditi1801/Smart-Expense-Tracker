using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using SmartExpenseTrackerGUI.Models;

namespace SmartExpenseTrackerGUI.Services;

public class FileService
{
    private readonly string _filePath = "transactions.json";

    public List<Transaction> LoadTransactions()
    {
        if (!File.Exists(_filePath))
            return new List<Transaction>();

        string json = File.ReadAllText(_filePath);

        if (string.IsNullOrWhiteSpace(json))
            return new List<Transaction>();

        return JsonSerializer.Deserialize<List<Transaction>>(json)
               ?? new List<Transaction>();
    }

    public void SaveTransactions(List<Transaction> transactions)
    {
        string json = JsonSerializer.Serialize(
            transactions,
            new JsonSerializerOptions
            {
                WriteIndented = true
            });

        File.WriteAllText(_filePath, json);
    }
}