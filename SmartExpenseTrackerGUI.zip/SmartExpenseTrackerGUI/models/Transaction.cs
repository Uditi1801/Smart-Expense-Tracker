using System;

namespace SmartExpenseTrackerGUI.Models;

public class Transaction
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Type { get; set; } = "";
    public string Category { get; set; } = "";
    public decimal Amount { get; set; }
    public string Note { get; set; } = "";
    public DateTime Date { get; set; } = DateTime.Now;
}